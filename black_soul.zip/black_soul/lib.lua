local Lib = {}

function Lib:init()
	print("the black soul loaded!")
end

return Lib
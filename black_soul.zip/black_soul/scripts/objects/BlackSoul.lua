local BlackSoul, super = Class(Soul)

function BlackSoul:init(x, y)
    super:init(self, x, y)

    self.sprite:setSprite("soul/black")


end

function BlackSoul:onStart()
    local arena = Game.battle.arena
end

function BlackSoul:update()
    super:update(self)
end

function BlackSoul:doMovement()
    local speed = self.speed

    -- Do speed calculations here if required.

    if self.allow_focus then
        if Input.down("cancel") then speed = speed / 2 end -- Focus mode.
    end

    local move_x, move_y = 0, 0

    -- Keyboard input:
    if Input.down("left")  then move_x = move_x + 1 end
    if Input.down("right") then move_x = move_x - 1 end
    if Input.down("up")    then move_y = move_y + 1 end
    if Input.down("down")  then move_y = move_y - 1 end

    self.moving_x = move_x
    self.moving_y = move_y

    if move_x ~= 0 or move_y ~= 0 then
        if not self:move(move_x, move_y, speed * DTMULT) then
            self.moving_x = 0
            self.moving_y = 0
        end
    end
end

return BlackSoul